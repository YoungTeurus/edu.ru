create
    definer = root@localhost procedure GetQuestionAnswers(IN _testId int, IN _questionId int)
BEGIN
    -- Все ответы на любой вопрос:
    SELECT id, answer, correct
        FROM testsanswers
            WHERE testId = _testId AND questionId = _questionId;
end;

