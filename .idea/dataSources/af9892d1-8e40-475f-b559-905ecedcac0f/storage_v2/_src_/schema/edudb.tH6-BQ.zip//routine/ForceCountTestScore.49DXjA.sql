create
    definer = root@localhost procedure ForceCountTestScore(IN _userId int, IN _testId int, IN _try int)
BEGIN
    DECLARE numOfQuestionsInTest, numOfCorrectAnswers INT;
    DECLARE _score FLOAT;
    SELECT questionsCount INTO numOfQuestionsInTest
    FROM questionscount
    WHERE testId = _testId;

    SELECT COUNT(*) INTO numOfCorrectAnswers FROM testsusersanswers WHERE userId = _userId AND testId = _testId AND try = _try AND correct = 1;
    SET _score = numOfCorrectAnswers / numOfQuestionsInTest;

    UPDATE testsresults
    SET score = _score, needsReview = 0
    WHERE testId = _testId
      AND userId = _userId
      AND try = _try;
END;

