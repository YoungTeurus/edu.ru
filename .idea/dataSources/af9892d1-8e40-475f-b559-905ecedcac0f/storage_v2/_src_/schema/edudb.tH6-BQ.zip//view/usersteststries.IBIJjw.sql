create definer = root@localhost view usersteststries as
select `edudb`.`testsresults`.`userId` AS `userId`,
       `edudb`.`testsresults`.`testId` AS `testId`,
       count(0)                        AS `testTries`
from `edudb`.`testsresults`
group by `edudb`.`testsresults`.`userId`, `edudb`.`testsresults`.`testId`;

