create definer = root@localhost trigger ActionsAfterInsert
    after insert
    on users
    for each row
BEGIN
        -- Добавляем для пользователя строку в таблице с данными пользователя
        INSERT INTO usersinfo(userId) VALUES (NEW.id);
        -- Вносим пользователя в стандартную общую группу:
        INSERT INTO usersstudentsgroups(userId, studentgroupId) VALUE (NEW.id, 1);
    END;

