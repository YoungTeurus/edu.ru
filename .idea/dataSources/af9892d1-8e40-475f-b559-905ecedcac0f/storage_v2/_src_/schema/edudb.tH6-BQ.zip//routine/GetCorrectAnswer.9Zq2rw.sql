create
    definer = root@localhost procedure GetCorrectAnswer(IN _testid int, IN _questionId int)
BEGIN
    -- Правильный ответ(-ы) на вопрос теста:
    -- Только вопросы с ответами
    SELECT answer
    FROM testsanswers ta
             JOIN testquestions tq ON tq.testId = ta.testId
        AND ta.testId = _testid
        AND questionId = _questionId
        AND tq.id = ta.questionId JOIN questiontypes q on q.id = tq.questionType
        AND hasCorrectAnswer = 1
    WHERE correct = 1;
END;

