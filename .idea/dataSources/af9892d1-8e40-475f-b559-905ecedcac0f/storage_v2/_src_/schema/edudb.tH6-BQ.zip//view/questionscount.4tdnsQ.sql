create definer = root@localhost view questionscount as
select `t`.`id` AS `testId`, count(`edudb`.`testquestions`.`id`) AS `questionsCount`
from (`edudb`.`tests` `t`
         left join `edudb`.`testquestions` on ((`t`.`id` = `edudb`.`testquestions`.`testId`)))
group by `edudb`.`testquestions`.`testId`;

