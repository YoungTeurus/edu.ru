create
    definer = root@localhost procedure RemoveStudentsGroupFromTest(IN _testId int, IN _studentgroupId int)
BEGIN
    DELETE FROM testsstudentsgroups
        WHERE testId = _testId AND studentgroupId = _studentgroupId;
end;

