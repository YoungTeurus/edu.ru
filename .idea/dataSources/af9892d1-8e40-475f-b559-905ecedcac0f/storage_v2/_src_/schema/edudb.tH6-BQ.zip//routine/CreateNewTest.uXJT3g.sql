create
    definer = root@localhost function CreateNewTest(_name varchar(256), _openDatetime datetime, _closeDatetime datetime,
                                                    _maxTries int, _timeToComplete time) returns int
BEGIN
    INSERT INTO tests(name, creationDatetime, openDatetime, closeDatetime, maxTries, timeToComplete)
        VALUE (_name, CURRENT_TIMESTAMP(), _openDatetime, _closeDatetime, _maxTries, _timeToComplete);
    RETURN LAST_INSERT_ID();
END;

