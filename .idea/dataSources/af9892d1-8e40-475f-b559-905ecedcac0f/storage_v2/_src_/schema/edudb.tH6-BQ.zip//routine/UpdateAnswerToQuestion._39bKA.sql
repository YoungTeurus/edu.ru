create
    definer = root@localhost procedure UpdateAnswerToQuestion(IN _testId int, IN _questionId int,
                                                              IN _text varchar(1024), IN _correct tinyint(1))
BEGIN
        UPDATE testsanswers
            SET answer = _text, correct = _correct
        WHERE testId = _testId AND questionId = _questionId;
    end;

