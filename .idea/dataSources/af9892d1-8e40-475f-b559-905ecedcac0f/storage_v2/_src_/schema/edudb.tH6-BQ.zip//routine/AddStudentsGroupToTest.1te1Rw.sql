create
    definer = root@localhost procedure AddStudentsGroupToTest(IN _testId int, IN _studentgroupId int)
BEGIN
    INSERT INTO testsstudentsgroups(testId, studentgroupId) VALUE (_testId, _studentgroupId);
end;

