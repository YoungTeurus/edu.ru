create
    definer = root@localhost function CanStartNewTry(_userId int, _testId int) returns tinyint(1)
BEGIN
    DECLARE currentTry, maxTestTries INT;
    DECLARE returnVar BOOLEAN;
    SELECT maxTries INTO maxTestTries
    FROM testsavaliabletouser
    WHERE testId = _testId AND userId = _userId;
    -- Если пользователь не может начать этот тест вообще, returnVar = false:
    SET returnVar = IF(maxTestTries IS NULL, false, true);
    -- Если maxTestTries == -1, значит тест можно проходить сколько угодно (10 миллионов) раз
    SET maxTestTries = IF(maxTestTries = -1, 2147483647 ,maxTestTries);
    SET currentTry = GetUserLastTestTry(_userId, _testId);
    -- Если максимальное количество попыток меньше или равно текущему числу попыток - возвращаем false.
    -- Если нет, то делаем операцию "И" над returnVar и true. Если до этого returnVar был false, останется false.
    SET returnVar = IF(maxTestTries <= currentTry, false, returnVar && true);
    RETURN returnVar;
END;

