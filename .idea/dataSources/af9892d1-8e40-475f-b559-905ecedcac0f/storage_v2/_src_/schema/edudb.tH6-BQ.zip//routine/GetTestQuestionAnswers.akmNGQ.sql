create
    definer = root@localhost procedure GetTestQuestionAnswers(IN _testId int, IN _questionId int)
BEGIN
    -- Только тестовые вопросы!
    SELECT answer
    FROM testsanswers ta JOIN testquestions tq on tq.testId = ta.testId and tq.id = ta.questionId JOIN questiontypes q on q.id = tq.questionType and hasVariants = 1
    WHERE ta.testId = _testId AND questionId = _questionId;
END;

