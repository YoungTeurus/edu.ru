create
    definer = root@localhost function GetUserLastTestTry(_userId int, _testId int) returns int
BEGIN
        DECLARE temp INT;
        SELECT testTries INTO temp
        FROM usersteststries
        WHERE testId = _testId AND userId = _userId;
        SET temp = IF(temp IS NULL, 0, temp);
        RETURN temp;
    END;

