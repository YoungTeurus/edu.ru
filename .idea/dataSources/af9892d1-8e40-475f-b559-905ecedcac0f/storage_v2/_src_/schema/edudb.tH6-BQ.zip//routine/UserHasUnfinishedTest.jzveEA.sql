create
    definer = root@localhost function UserHasUnfinishedTest(_userId int, _testId int) returns tinyint(1)
BEGIN
        DECLARE hasNotFinished BOOLEAN;
        -- Проверяем, проходит ли пользователь тест в данный момент (начал ли он его):
        -- Если минимальный флаг finished в заданном тесте = 0, то true.
        SELECT IFNULL(IF(MIN(finished) = 0, 1, 0), 0) INTO hasNotFinished
        FROM testsresults
        WHERE userId = _userId AND testId = _testId;
        RETURN hasNotFinished;
    end;

