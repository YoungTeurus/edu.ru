create
    definer = root@localhost function GetCurrentTestTry(_userId int, _testId int) returns int
BEGIN
    DECLARE temp INT;
    SELECT try INTO temp
           FROM testsresults
        WHERE userId = _userId AND testId = _testId AND finished = 0 LIMIT 1;
    SET temp = IF(temp IS NULL, 0, temp);
    RETURN temp;
END;

