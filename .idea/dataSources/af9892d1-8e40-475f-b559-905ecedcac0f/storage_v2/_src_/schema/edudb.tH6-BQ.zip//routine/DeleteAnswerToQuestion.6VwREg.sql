create
    definer = root@localhost procedure DeleteAnswerToQuestion(IN _answerId int)
BEGIN
    DELETE FROM testsanswers
        WHERE id = _answerId;
end;

