create
    definer = root@localhost procedure UpdateAnswerToQuestion(IN _answerId int, IN _text varchar(1024), IN _correct tinyint(1))
BEGIN
        UPDATE testsanswers
            SET answer = _text, correct = _correct
        WHERE id = _answerId;
    end;

