create definer = root@localhost trigger AfterInsert
    after insert
    on users
    for each row
    INSERT INTO usersstudentsgroups(userId, studentgroupId) VALUE (NEW.id, 1);

