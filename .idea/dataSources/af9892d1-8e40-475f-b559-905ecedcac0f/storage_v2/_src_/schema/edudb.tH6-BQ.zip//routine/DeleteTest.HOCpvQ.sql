create
    definer = root@localhost procedure DeleteTest(IN _id int)
BEGIN
    DELETE FROM tests
        WHERE id = _id;
end;

