create
    definer = root@localhost procedure UpdateTest(IN _id int, IN _name varchar(256), IN _openDatetime datetime,
                                                  IN _closeDatetime datetime, IN _maxTries int, IN _timeToComplete time)
BEGIN
    UPDATE tests
    SET name = _name, openDatetime = _openDatetime, closeDatetime = _closeDatetime, maxTries = _maxTries, timeToComplete = _timeToComplete
    WHERE id = _id;
END;

