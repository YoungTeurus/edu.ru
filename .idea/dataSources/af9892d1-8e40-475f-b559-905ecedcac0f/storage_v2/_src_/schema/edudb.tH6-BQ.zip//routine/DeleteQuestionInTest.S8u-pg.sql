create
    definer = root@localhost procedure DeleteQuestionInTest(IN _testId int, IN _questionId int)
BEGIN
    DELETE FROM testquestions
        WHERE testId = _testId AND id = _questionId;
end;

