create
    definer = root@localhost procedure RegisterUser(IN _login varchar(64), IN _passwordHash varbinary(256))
BEGIN
    INSERT INTO users(login, passwordHash, groupId) VALUES (_login, _passwordHash, 1);
    SELECT id FROM users WHERE login = _login;
end;

