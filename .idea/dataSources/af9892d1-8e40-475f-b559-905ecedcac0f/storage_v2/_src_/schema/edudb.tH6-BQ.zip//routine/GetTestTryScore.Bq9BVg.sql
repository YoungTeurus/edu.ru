create
    definer = root@localhost function GetTestTryScore(_testId int, _userId int, _try int) returns float
BEGIN
        DECLARE testScore FLOAT;
        SELECT score INTO testScore
        FROM testsresults
        WHERE testId = _testId AND userId = _userId AND try = _try;
        RETURN testScore;
    end;

