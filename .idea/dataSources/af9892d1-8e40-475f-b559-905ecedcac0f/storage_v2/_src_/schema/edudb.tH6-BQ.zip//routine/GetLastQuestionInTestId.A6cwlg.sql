create
    definer = root@localhost function GetLastQuestionInTestId(_testId int) returns int
BEGIN
        -- Получить порядковый номер последнего вопроса в тесте
        -- Если вопросов ещё не создано, возвращает 0
        DECLARE returnVar INT;
        SELECT MAX(id) INTO returnVar
            FROM testquestions
                WHERE testId = _testId;
        SET returnVar = IF(returnVar IS NULL, 0, returnVar);
        RETURN returnVar;
    END;

