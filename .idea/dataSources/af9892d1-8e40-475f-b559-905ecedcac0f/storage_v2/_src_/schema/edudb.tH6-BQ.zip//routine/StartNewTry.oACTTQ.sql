create
    definer = root@localhost procedure StartNewTry(IN _userId int, IN _testId int)
BEGIN
    INSERT INTO testsresults(userId, testId,
                             try, finished,
                             startedDatetime)
        VALUE (
               _userId, _testId, GetUserLastTestTry(_userId, _testId) + 1, 0, CURRENT_TIMESTAMP()
        );
end;

