create definer = root@localhost view testsavaliabletouser as
select `u`.`userId`                         AS `userId`,
       `edudb`.`tests`.`id`                 AS `testId`,
       `edudb`.`tests`.`name`               AS `name`,
       `edudb`.`tests`.`creationDatetime`   AS `creationDatetime`,
       `edudb`.`tests`.`openDatetime`       AS `openDatetime`,
       `edudb`.`tests`.`closeDatetime`      AS `closeDatetime`,
       `edudb`.`tests`.`maxTries`           AS `maxTries`,
       `edudb`.`tests`.`timeToComplete`     AS `timeToComplete`,
       ifnull(max(`tr`.`try`), 0)           AS `usedTries`,
       ifnull(max(`tr`.`finished`), 0)      AS `isCompleted`,
       if((min(`tr`.`finished`) = 0), 1, 0) AS `inProgress`
from ((((`edudb`.`tests` join `edudb`.`testsstudentsgroups` `t` on ((`edudb`.`tests`.`id` = `t`.`testId`))) join `edudb`.`studentsgroups` `s` on ((`t`.`studentgroupId` = `s`.`id`))) join `edudb`.`usersstudentsgroups` `u` on ((`s`.`id` = `u`.`studentgroupId`)))
         left join `edudb`.`testsresults` `tr`
                   on (((`u`.`userId` = `tr`.`userId`) and (`edudb`.`tests`.`id` = `tr`.`testId`))))
group by `u`.`userId`, `edudb`.`tests`.`id`, `edudb`.`tests`.`name`, `edudb`.`tests`.`creationDatetime`,
         `edudb`.`tests`.`openDatetime`, `edudb`.`tests`.`closeDatetime`, `edudb`.`tests`.`maxTries`,
         `edudb`.`tests`.`timeToComplete`;

