create definer = root@localhost view testsavaliabletouser as
select `u`.`userId`                       AS `userId`,
       `edudb`.`tests`.`id`               AS `testId`,
       `edudb`.`tests`.`name`             AS `name`,
       `edudb`.`tests`.`creationDatetime` AS `creationDatetime`,
       `edudb`.`tests`.`openDatetime`     AS `openDatetime`,
       `edudb`.`tests`.`closeDatetime`    AS `closeDatetime`,
       `edudb`.`tests`.`maxTries`         AS `maxTries`,
       `edudb`.`tests`.`timeToComplete`   AS `timeToComplete`
from (((`edudb`.`tests` join `edudb`.`testsstudentsgroups` `t` on ((`edudb`.`tests`.`id` = `t`.`testId`))) join `edudb`.`studentsgroups` `s` on ((`t`.`studentgroupId` = `s`.`id`)))
         join `edudb`.`usersstudentsgroups` `u` on ((`s`.`id` = `u`.`studentgroupId`)));

