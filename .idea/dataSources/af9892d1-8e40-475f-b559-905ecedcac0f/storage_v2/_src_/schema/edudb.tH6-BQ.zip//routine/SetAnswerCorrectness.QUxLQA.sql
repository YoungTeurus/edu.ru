create
    definer = root@localhost procedure SetAnswerCorrectness(IN _testId int, IN _questionId int, IN _try int,
                                                            IN _userId int, IN _correct tinyint(1))
BEGIN
    UPDATE testsusersanswers
        SET correct = _correct
    WHERE testId = _testId AND questionId = _questionId AND try = _try AND userId = _userId;
end;

