create
    definer = root@localhost procedure DeleteAllAnswersToQuestion(IN _testId int, IN _questionId int)
BEGIN
    DELETE FROM testsanswers
    WHERE testId = _testId AND questionId = _questionId;
end;

