create
    definer = root@localhost procedure RegisterUser(IN _login varchar(64), IN _passwordHash varbinary(256),
                                                    IN _email varchar(128))
BEGIN
    INSERT INTO users(login, passwordHash, groupId) VALUES (_login, _passwordHash, 1);
    INSERT INTO usersinfo(userId, email) VALUE (LAST_INSERT_ID(), _email);
    SELECT id FROM users WHERE login = _login;
end;

