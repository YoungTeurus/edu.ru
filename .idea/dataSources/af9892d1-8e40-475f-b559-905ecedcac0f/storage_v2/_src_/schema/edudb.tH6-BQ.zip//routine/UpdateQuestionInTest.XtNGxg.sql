create
    definer = root@localhost procedure UpdateQuestionInTest(IN _testId int, IN _questionId int, IN _text varchar(1024),
                                                            IN _questionType int)
BEGIN
    UPDATE testquestions
    SET text = _text, questionType = _questionType
    WHERE testId = _testId AND id = _questionId;
end;

