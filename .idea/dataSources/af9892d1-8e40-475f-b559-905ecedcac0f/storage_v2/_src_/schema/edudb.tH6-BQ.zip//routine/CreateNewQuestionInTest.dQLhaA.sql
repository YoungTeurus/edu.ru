create
    definer = root@localhost function CreateNewQuestionInTest(_testId int, _text varchar(1024), _questionType int) returns int
BEGIN
    -- Добавляет к тесту новый вопрос
    -- Возвращает id нового вопроса
    DECLARE newQuestionId INT;
    SET newQuestionId = GetLastQuestionInTestId(_testId) + 1;
    INSERT INTO testquestions(testId, id, text, questionType) VALUE (_testId, newQuestionId, _text, _questionType);
    RETURN newQuestionId;
end;

