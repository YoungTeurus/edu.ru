create
    definer = root@localhost function CreateNewAnswerToQuestion(_testId int, _questionId int, _text varchar(1024),
                                                                _correct tinyint(1)) returns int
BEGIN
    INSERT INTO testsanswers(testId, questionId, answer, correct) VALUE (_testId, _questionId, _text, _correct);
    RETURN LAST_INSERT_ID();
end;

