create
    definer = root@localhost procedure EndCurrentTestTry(IN _userId int, IN _testId int)
BEGIN
    -- Завершить текущую (неоконченную) попытку прохождения пользователем определённого теста
    -- Проверяет, выполнены ли все задания, и если так - выставляет score и флаг needReview.
    DECLARE _try, numOfQuestionsInTest, numOfCorrectAnswers INT;
    DECLARE _score FLOAT;
    DECLARE _needsReview BOOLEAN;
    SET _try = GetCurrentTestTry(_userId, _testId);
    SELECT questionsCount INTO numOfQuestionsInTest
    FROM questionscount
    WHERE testId = _testId;

    -- Если в тесте есть хотя бы одно задание без правильного ответа, не можем проверять автоматически.
    IF((SELECT COUNT(*)
                   FROM testquestions JOIN questiontypes q on q.id = testquestions.questionType
                   WHERE testId = _testId AND hasCorrectAnswer = 0) = 0)
    THEN
        -- Если можем проверить автоматически:
        SELECT COUNT(*) INTO numOfCorrectAnswers FROM testsusersanswers WHERE userId = _userId AND testId = _testId AND try = _try AND correct = 1;
        SET _score = numOfCorrectAnswers / numOfQuestionsInTest;
        SET _needsReview = 0;
    ELSE
        -- Если не можем проверить автоматически:
        SET _score = -1;
        SET _needsReview = 1;
    END IF;

    UPDATE testsresults
    SET finished = 1, score = _score, needsReview = _needsReview
    WHERE testId = _testId
      AND userId = _userId
      AND try = _try;
END;

