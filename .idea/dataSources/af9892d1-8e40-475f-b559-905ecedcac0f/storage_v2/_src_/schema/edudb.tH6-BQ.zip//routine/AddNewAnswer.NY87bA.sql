create
    definer = root@localhost procedure AddNewAnswer(IN _userId int, IN _testId int, IN _questionId int,
                                                    IN _answer varchar(1024))
BEGIN
    -- Добавление нового ответа на вопрос начатого теста от пользователя:
-- При возможности производится проверка.
    DECLARE isAnswerCorrect BOOLEAN;
    SET isAnswerCorrect = IF((SELECT IF(COUNT(*) > 0, true, false) AS isCorrect
-- Если находим хотя бы 1 ответ, который correct и текст которого == :answer, считаем, что ответ верен
                              FROM (SELECT answer
                                    FROM testsanswers ta JOIN testquestions tq ON
                                                tq.testId = ta.testId AND ta.testId = _testId AND questionId = _questionId
                                            AND tq.id = ta.questionId AND correct = 1
                                   ) as t
                              WHERE answer = _answer), true, false);
    INSERT INTO testsusersanswers(testId, questionId, try,
                                  userId, datetime, answer, correct)
        VALUE (_testId, _questionId, GetCurrentTestTry(_userId, _testId),
               _userId, CURRENT_TIMESTAMP(), _answer, isAnswerCorrect);
END;

