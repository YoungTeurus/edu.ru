create view logsextended as
select `lab5db`.`logs`.`id`               AS `id`,
       `lab5db`.`logs`.`clientIp`         AS `clientIp`,
       `lab5db`.`logs`.`date`             AS `date`,
       `lab5db`.`logs`.`requestType`      AS `requestType`,
       `lab5db`.`logs`.`requestURL`       AS `requestURL`,
       `lab5db`.`logs`.`requestVersion`   AS `requestVersion`,
       `lab5db`.`logs`.`answerCode`       AS `answerCode`,
       `lab5db`.`logs`.`answerLength`     AS `answerLength`,
       `lab5db`.`logs`.`refererURL`       AS `refererURL`,
       `lab5db`.`logs`.`userAgent`        AS `userAgent`,
       dayofmonth(`lab5db`.`logs`.`date`) AS `day`,
       month(`lab5db`.`logs`.`date`)      AS `month`,
       dayname(`lab5db`.`logs`.`date`)    AS `dayOfWeek`,
       hour(`lab5db`.`logs`.`date`)       AS `hour`
from `lab5db`.`logs`;

